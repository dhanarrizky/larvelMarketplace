class countConsonants:
    
    def vocalConso(self, text):
        txt = text.lower()
        vocal = ['a','i','u','e','o']
        consonants  = ['b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y','z']
        vocCount = 0
        conCount = 0
        for j in txt:
            for i in vocal:
                if j == i:
                    vocCount +=1
        for y in txt:
            for z in consonants:
                if y == z:
                    conCount +=1
        print(vocCount)
        print(conCount)


# conso = countConsonants("Hallo World")
test = countConsonants()

test.vocalConso("hallo")