class reverseMethod:
    
    def __init__(self, text):
        print(text[::-1])
        
reverse = reverseMethod("hallo world")