class Hero:
    
    def __init__(self,name,health,attack):
        self.name = name
        self.health = health
        self.attack = attack
        
heroOne = Hero('dhanar',100,50)
heroTwo = Hero('Rizky',200,60)

print(heroOne.__dict__)
print(heroTwo.__dict__)