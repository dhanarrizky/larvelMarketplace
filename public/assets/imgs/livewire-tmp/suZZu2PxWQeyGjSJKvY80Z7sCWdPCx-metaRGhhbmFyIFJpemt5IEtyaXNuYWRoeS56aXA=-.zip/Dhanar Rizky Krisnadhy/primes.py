class primes:
    def primesCheck(self,num):
        if (num == 0) or (num == 1):
            return False
        elif num == 2:
            return True
        elif num <= 0:
            return False
        else:
            for i in range(2,num):
                if num%2 == 0:
                    return False
                else:
                    return True
                

bil = primes()
print(bil.primesCheck(-1))