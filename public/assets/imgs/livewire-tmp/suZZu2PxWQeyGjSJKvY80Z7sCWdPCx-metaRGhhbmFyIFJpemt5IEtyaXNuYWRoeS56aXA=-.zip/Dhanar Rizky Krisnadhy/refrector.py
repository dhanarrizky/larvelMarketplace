# function someMethod(int n) {
#  n= Math.abs(n);
#  boolean out = true;
#  for (int i = 0; i < n; i++) {
#  out = !out;
#  }

#  return out;
# }
class someMethod:
    def someMethod(self,n):
        n= abs(n)
        out = True
        for i in range(0,n):
            if i%2 == 0:
                out = True
            else:
                out = False
        return out

num =someMethod()
print(num.someMethod(1))