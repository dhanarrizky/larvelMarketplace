class duplicate_arrays:
    def duplicateArrays(self, arr):
        print( list(dict.fromkeys(arr)))
        
ary = duplicate_arrays()

ary.duplicateArrays([2,3,3,4,5,5,6])